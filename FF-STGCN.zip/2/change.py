import numpy as np
import torch

# path = 'data/NewYork/'
# rent_dataset = 'data/NewYork/pickup.npy'
# rent_flow_dataset = 'data/NewYork/rent2return.npy'
# return_dataset = 'data/NewYork/dropoff.npy'
# return_flow_dataset = 'data/NewYork/return2rent.npy'
# np.save(path+'pickup_120.npy', torch.tensor(np.load(rent_dataset)[:, 0:120]))
# np.save(path+'rent2return_120.npy', torch.tensor(np.load(rent_flow_dataset)[:, 0:120, 0:120]))
# np.save(path+'dropoff_120.npy', torch.tensor(np.load(return_dataset)[:, 0:120]))
# np.save(path+'return2rent_120.npy', torch.tensor(np.load(return_flow_dataset)[:, 0:120, 0:120]))
path = 'data/NewYork/difference.npy'
difference = torch.tensor(np.load(path))
np.save('data/NewYork/difference_120.npy', difference[:, 0:120])
