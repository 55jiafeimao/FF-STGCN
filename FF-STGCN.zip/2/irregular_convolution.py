import numpy as np
import pandas as pd
import torch
import torch.nn as nn
from scipy.spatial.distance import squareform, pdist
from torch.autograd import Variable
from torch.nn import init
from dtw import dtw

class irregular_convolution(nn.Module):
    def __init__(self, in_channel, out_channel, kernel_length = 330, num_node = 330, bias = True):
        super(irregular_convolution, self).__init__()
        self.in_channel = in_channel
        self.out_channel = out_channel
        self.num_node = num_node
        self.kernel_length = kernel_length
        self.kernel_fun_bias = nn.Linear(self.in_channel * self.kernel_length, self.out_channel).cuda()
        self.kernel_fun = nn.Linear(self.in_channel * self.kernel_length, self.out_channel, bias=False).cuda()
        self.bias = bias

    def forward(self, x_input):
        reshape_size = self.in_channel * self.kernel_length
        x_size = x_input.size()
        x_input = x_input.permute(0, 1, 3, 2).reshape([x_size[0], x_size[2], reshape_size])
        if self.bias:
            output = self.kernel_fun_bias(x_input).permute(0, 2, 1).unsqueeze(-1)
        else:
            output = self.kernel_fun(x_input).permute(0, 2, 1).unsqueeze(-1)
        return output


class Extraction_spatial_features(nn.Module):
    def __init__(self,  difference, pearson, kernel_size=330, total_nodes=330):
        """
        This module is to capture spatial dependency of bicycle usage for each interval in a sequence using irregular
        convolution operations.

        The built-in function, self.prepare_data(), is to select the semantic neighbors for each central cell using
        a Pytorch function torch.masked_select().

        The function, reconstruction_file(), is to read the look-up table for mapping relationship between central cells
        and their corresponding semantic neighbors. The return of this function is the input for torch.masked_select().
        :param kernel_size: int, The size of irregular convolution kernel size (default: 9)
        :param seq_len: int, The length of sequence (default:24)
        :param total_nodes:The number of nodes (cells involved in this study)(default: 125 cells in New York)
        """
        super(Extraction_spatial_features, self).__init__()
        self.total_nodes=total_nodes
        self.kernel_size = kernel_size
        self.relu = nn.ReLU(inplace=True)
        self.first_no_layer = 32
        self.second_no_layer = 16
        self.irregular_layer1 = irregular_convolution(1, self.first_no_layer, kernel_length=self.kernel_size)
        self.irregular_layer2 = irregular_convolution(self.first_no_layer, self.second_no_layer, kernel_length=self.kernel_size)
        self.batchnormal = nn.BatchNorm2d(self.second_no_layer).cuda()
        self.temporal_out = torch.ones([self.total_nodes, 1])
        self.reduce_dimension = irregular_convolution(self.second_no_layer, 1, kernel_length=self.kernel_size)
        self.difference = difference
        self.pearson = pearson
        # reduce the dimension of the high-level features to 1

    def reconstruction_file(self, batch_size_hour_idxs):

        timeSeries = self.difference[batch_size_hour_idxs, 0:self.total_nodes].T
        temp = []
        a = lambda x, y: np.abs(x-y)
        for i in timeSeries:
            temp.append([dtw(i, j, dist=a)[0] for j in timeSeries])
        dtwlist = [x for x in temp]
        dtwarray = np.array(dtwlist)
        change_dtwarray = np.divide(1, dtwarray, out=np.zeros_like(dtwarray), where=dtwarray != 0)
        site_score = self.pearson * change_dtwarray
        # site_score = dtwarray
        # site_score = self.pearson
        site_score = np.nan_to_num(site_score, nan=0, posinf=0, neginf=0)
        site_score_norm = np.divide(site_score, np.linalg.norm(site_score, axis=0), out=np.zeros_like(site_score),
                                    where=np.linalg.norm(site_score, axis=0) != 0)
        site_top = np.argsort(-site_score_norm, axis=1)[:, 1:10]
        mask = np.zeros((self.total_nodes, self.total_nodes))
        for i in range(self.total_nodes):
            for j in range(9):
                index = site_top[i][j]
                mask[i][index] = 1
        return mask, site_top
    def prepare_data(self, input_x, mask):
        """
        This function is to prepare the tensor based on the map between central cells and their corresponding neighbors.
        :param input_x: A tensor needs to re-structure following the look-up table.
        :return:
        """
        shape = input_x.size()
        temporal_out = torch.matmul(self.temporal_out, input_x.cpu())
        temporal_out = torch.masked_select(temporal_out, mask.cpu()).reshape(shape[0], shape[1], shape[3], 9)
        return temporal_out

    def forward(self, input, batch_size_hour_idxs):
        """
        This forward function captures spatial dependency of bicycle usage for each interval in a sequence.
        :param input: The sequence of historical bicycle usage.
        :return: A tensor with captured spatial dependency, which will be input into the LSTM module.
        """
        mask, site_top = self.reconstruction_file(batch_size_hour_idxs)
        x_input = torch.Tensor().cuda()
        for i in range(self.total_nodes):
            x = torch.unsqueeze(input[:, i, site_top[i]], 1)
            x_input = torch.cat([x_input, x], dim=1)
        x_input = torch.unsqueeze(x_input, 1)
        mask = torch.tensor(mask, dtype=torch.bool).cuda()
        cnn_output = self.relu(self.irregular_layer1(x_input)).permute(0, 1, 3, 2)
        cnn_input = self.prepare_data(input_x=cnn_output, mask=mask)
        cnn_output = self.relu(self.batchnormal(self.irregular_layer2(cnn_input.cuda()))).permute(0, 1, 3, 2)
        cnn_input = self.prepare_data(input_x=cnn_output, mask=mask)
        cnn_output = self.reduce_dimension(cnn_input.cuda())
        cnn_output = self.relu(cnn_output)
        cnn_output = cnn_output.squeeze(-1).squeeze(1)
        return cnn_output



# def load_similar():
#     similar = np.load('data/NewYork/similar.npy')
#     return similar
# def reconstruction_file(kernel_size):
#     """
#     This function returns the look-up table for central cells to check their corresponding semantic neighbors.
#     In this instance, we use the metric calculated by DTW algorithm in New York.
#     The look-up table is named as DTW_Similarity_Table.csv in NYC folder.
#     :param kernel_size: int, the size of convolution kernel.
#     :return: look-up table for mapping central cells with their corresponding semantic neighbors.
#     """
#     node_list, correlation_table = [], {}
#     file_map = open('NYC/DTW_Similarity_Table.csv', 'r')
#     for line in file_map:
#         line_element = line.strip().split(':')
#         node_id = line_element[0]
#         value_list = line_element[1].split(',')
#         node_list.append(node_id)
#         correlation_table[node_id] = value_list
#     node_index_dict = {}
#     for index, item in enumerate(node_list):
#         node_index_dict[item] = index
#     correlation_table_index = {}
#     for key in correlation_table:
#         for index, item in enumerate(correlation_table[key]):
#             if index < kernel_size:
#                 if node_index_dict[key] not in correlation_table_index:
#                     correlation_table_index[node_index_dict[key]] = [node_index_dict[item]]
#                 else:
#                     correlation_table_index[node_index_dict[key]].append(node_index_dict[item])
#
#     zero_matrix = []
#     for key in correlation_table_index:
#         temp_zero = []
#         for i in range(125):
#             if i in correlation_table_index[key]:
#                 temp_zero.append(1)
#             else:
#                 temp_zero.append(0)
#         zero_matrix.append(temp_zero)
#
#     return zero_matrix
