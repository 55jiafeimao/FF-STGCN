import torch
import torch.nn as nn
# from sklearn.metrics import mean_absolute_error, mean_squared_error
from torch.nn import init
import torch.nn.functional as F

from AFF import MS_CAM
from cnn import CnnDay, CnnHour
from encoders import Encoder
from Gat import GAT
from irregular_convolution import Extraction_spatial_features

class STGNN(nn.Module):
    def __init__(self, feature_dim, embed_dim, m_size, day, hour, batch_size, difference, pearson):
        super(STGNN, self).__init__()
        self.m_size = m_size
        self.graph = Encoder(feature_dim, embed_dim, m_size, hour)
        # self.gat = GAT(nfeat = feature_dim, nhid = 8, nclass = 4, dropout = 0.5, nheads = 2, alpha = 0.5)

        self.day = MS_CAM(day, 7, batch_size, m_size)
        self.hour = MS_CAM(hour, 4, batch_size, m_size)
        self.conv_module = Extraction_spatial_features(difference, pearson,kernel_size=9, total_nodes=m_size)
        self.embed_size = 4 + 4
        
        self.rnn = nn.GRU(self.embed_size,  self.embed_size, 2)

        self.w1 = nn.Parameter(torch.FloatTensor(m_size, m_size))
        init.xavier_uniform_(self.w1)
        self.w2 = nn.Parameter(torch.FloatTensor(m_size, m_size))
        init.xavier_uniform_(self.w2)
        self.w3 = nn.Parameter(torch.FloatTensor(m_size, m_size))
        init.xavier_uniform_(self.w3)
        self.w4 = nn.Parameter(torch.FloatTensor(m_size, m_size))
        init.xavier_uniform_(self.w4)
        self.w5 = nn.Parameter(torch.FloatTensor(m_size, m_size))
        init.xavier_uniform_(self.w5)

        self.tran_Matrix = nn.Parameter(torch.FloatTensor(2, self.embed_size))
        init.xavier_uniform_(self.tran_Matrix)
        self.hn = nn.Parameter(torch.FloatTensor(2, self.m_size, self.embed_size))
        init.xavier_uniform_(self.hn)
        
        self.loss_fn = torch.nn.MSELoss()
        self.loss_mae = torch.nn.L1Loss(reduction='mean')

    def forward(self, feat_rent_days, feat_rent_hours, feat_return_days, feat_return_hours, batch_size_hour_idxs):

        # flow graph
        node_rent_days = self.day(feat_rent_days)
        node_rent_hours = self.hour(feat_rent_hours)
        node_return_days = self.day(feat_return_days)
        node_return_hours = self.hour(feat_return_hours)

        feat_matrix = torch.cat([node_rent_days, node_rent_hours, node_return_days, node_return_hours], dim = 2)

        edge_rent_days = self.day(feat_rent_days)
        edge_rent_hours = self.hour(feat_rent_hours)
        edge_return_days = self.day(feat_return_days)
        edge_return_hours = self.hour(feat_return_hours)

        adj_matrix = self.w1 * edge_rent_days.cpu() + self.w2 * edge_rent_hours.cpu() + self.w3 * edge_return_days.cpu() + self.w4 * edge_return_hours.cpu()

        out_flow = self.graph(feat_matrix, adj_matrix)
        size = out_flow.shape
        # out_flow = torch.reshape(out_flow, (size[0], size[1], self.m_size))
        # Similar graph

        node_rent_days_similar = self.w5.cuda() *self.day(feat_rent_days)
        node_rent_hours_similar = self.w5.cuda() *self.hour(feat_rent_hours)
        node_return_days_similar = self.w5.cuda() *self.day(feat_return_days)
        node_return_hours_similar = self.w5.cuda() *self.hour(feat_return_hours)

        rent_days = torch.unsqueeze(self.conv_module(node_rent_days_similar, batch_size_hour_idxs),1)
        rent_hours = torch.unsqueeze(self.conv_module(node_rent_hours_similar, batch_size_hour_idxs),1)
        return_days = torch.unsqueeze(self.conv_module(node_return_days_similar, batch_size_hour_idxs),1)
        return_hours = torch.unsqueeze(self.conv_module(node_return_hours_similar, batch_size_hour_idxs),1)
        out_similar = torch.cat([rent_days, rent_hours, return_days, return_hours],1)
        output = torch.cat([out_flow, out_similar], dim=1).cpu()
        input = torch.transpose(output, 1, 2)
        output, hn = self.rnn(input, self.hn)
        self.hn = nn.Parameter(hn)
        # output = output.reshape(size[0], self.m_size, self.embed_size)
        output = torch.transpose(output, 1, 2)
        scores = torch.matmul(self.tran_Matrix, output).cuda()

        return scores

    def loss1(self, scores, ground_truth):
        if len(ground_truth.shape) != 3:
            ground_truth = ground_truth.unsqueeze(0)
        ground_truth = ground_truth.cuda()
        mse = self.loss_fn(scores, ground_truth)
        mae = self.loss_mae(scores, ground_truth)
        print("MSE:", mse)
        print("MAE:", mae)
        return mse, mae

    def loss2(self, score, ground_truth):
        if len(ground_truth.shape) != 3:
            ground_truth = ground_truth.unsqueeze(0)
        ground_truth = ground_truth.cuda()
        loss = self.loss_mae(score, ground_truth)
        return loss
