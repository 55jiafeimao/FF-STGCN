# from torch_geometric import nn
import torch
import torch.nn as nn
from torch.nn import init
import torch.nn.functional as F


class AFF(nn.Module):
    '''
    多特征融合 AFF
    '''

    def __init__(self, channels=64, r=4, m_size=330):
        super(AFF, self).__init__()
        inter_channels = int(channels // r)
        self.m_size = m_size
        self.local_att = nn.Sequential(
            nn.Conv2d(channels, inter_channels, kernel_size=1, stride=1, padding=0),
            nn.BatchNorm2d(inter_channels),
            nn.ReLU(inplace=True),
            nn.Conv2d(inter_channels, channels, kernel_size=1, stride=1, padding=0),
            nn.BatchNorm2d(channels),
        )

        self.global_att = nn.Sequential(
            nn.AdaptiveAvgPool2d(1),
            nn.Conv2d(channels, inter_channels, kernel_size=1, stride=1, padding=0),
            # nn.BatchNorm2d(inter_channels),
            nn.ReLU(inplace=True),
            nn.Conv2d(inter_channels, channels, kernel_size=1, stride=1, padding=0),
            # nn.BatchNorm2d(channels),
        )
        self.cnnHour = nn.Sequential(
            nn.Conv2d(in_channels=48, out_channels=1, kernel_size=1, stride=1, padding=0),
            nn.ReLU(inplace=True)
        )
        self.cnnDay = nn.Sequential(
            nn.Conv2d(in_channels=7, out_channels=1, kernel_size=1, stride=1, padding=0),
            nn.ReLU(inplace=True)
        )
        self.sigmoid = nn.Sigmoid()
        self.dropout = nn.Dropout(0.5).cuda()
        self.local_att = self.local_att.cuda()
        self.global_att = self.global_att.cuda()

    def forward(self, x, residual):
        x = torch.unsqueeze(x, 0)
        residual = torch.unsqueeze(residual, 0)
        x = self.cnnHour(x.cpu())
        residual = self.cnnDay(residual.cpu())
        xa = x + residual
        xl = self.local_att(xa.cuda())
        xg = self.global_att(xa.cuda())
        xlg = xl.cpu() + xg.cpu()
        wei = self.sigmoid(xlg)
        wei = wei.cuda()
        xo = 2 * x.cuda() * wei + 2 * residual.cuda() * (1 - wei)
        output = self.dropout(xo)
        return output.reshape(self.m_size, self.m_size)


class MS_CAM(nn.Module):
    '''
    单特征 进行通道加权,作用类似SE模块
    '''

    def __init__(self, channels=64, r=4,batch_size=4,m_size = 330):
        super(MS_CAM, self).__init__()
        inter_channels = int(channels // r)
        self.batch_size = batch_size
        self.m_size = m_size
        self.local_att = nn.Sequential(
            nn.Conv2d(channels, inter_channels, kernel_size=1, stride=1, padding=0),
            nn.BatchNorm2d(inter_channels),
            nn.ReLU(inplace=True),
            nn.Conv2d(inter_channels, channels, kernel_size=1, stride=1, padding=0),
            nn.BatchNorm2d(channels)
            # nn.Conv2d(channels, 1, kernel_size=1, stride=1, padding=0)
        )

        self.global_att = nn.Sequential(
            nn.AdaptiveAvgPool2d(1),
            nn.Conv2d(channels, inter_channels, kernel_size=1, stride=1, padding=0),
            nn.BatchNorm2d(inter_channels),
            nn.ReLU(inplace=True),
            nn.Conv2d(inter_channels, channels, kernel_size=1, stride=1, padding=0),
            nn.BatchNorm2d(channels)
            # nn.Conv2d(channels, 1, kernel_size=1, stride=1, padding=0)
        )
        self.local_att2 = nn.Sequential(
            nn.Conv2d(channels, inter_channels, kernel_size=1, stride=1, padding=0),
            nn.ReLU(inplace=True),
            nn.Conv2d(inter_channels, channels, kernel_size=1, stride=1, padding=0),
            # nn.Conv2d(channels, 1, kernel_size=1, stride=1, padding=0)
        )

        self.global_att2 = nn.Sequential(
            nn.AdaptiveAvgPool2d(1),
            nn.Conv2d(channels, inter_channels, kernel_size=1, stride=1, padding=0),
            nn.ReLU(inplace=True),
            nn.Conv2d(inter_channels, channels, kernel_size=1, stride=1, padding=0),
            # nn.Conv2d(channels, 1, kernel_size=1, stride=1, padding=0)
        )
        self.cnn = nn.Conv2d(in_channels=channels,
                             out_channels=1,
                             kernel_size=1,
                             stride=1,
                             padding=0)
        self.sigmoid = nn.Sigmoid()
        self.local_att = self.local_att.cuda()
        self.global_att = self.global_att.cuda()
        self.local_att2 = self.local_att2.cuda()
        self.global_att2 = self.global_att2.cuda()
        self.cnn = self.cnn.cuda()
        self.dropout = nn.Dropout(p=0.5)
    def forward(self, x):
        shape = x.shape
        batch_size = -1
        if len(shape) == 4:
            xl = self.local_att(x)
            xg = self.global_att(x)
            xlg = xl + xg
            wei = self.sigmoid(xlg)
            output = x * wei.cuda()
            batch_size = self.batch_size
        else:
            x = x.unsqueeze(0)
            xl = self.local_att2(x)
            xg = self.global_att2(x)
            xlg = xl + xg
            wei = self.sigmoid(xlg)
            output = x * wei
            batch_size = 1
        output = self.cnn(output)
        output = self.dropout(output)
        return output.reshape(batch_size, self.m_size, self.m_size)
        # return output


