import torch
import numpy as np
import pandas as pd
from scipy import sparse

def load_dataset(path, dataset, flow_dataset, m_size):
    # df = np.load(path + dataset +'.npy', mmap_mode='c')
    # para = np.max(df)
    # data = df
    # # data = df / para
    #
    # sp_flow = sparse.load_npz(path + flow_dataset +'.npz')
    # flow = sp_flow.toarray()
    # scale = np.max(flow)
    #
    # flow = flow.reshape(-1, m_size, m_size)

    data = np.load(path + dataset + '.npy')[0:19872, :]
    para = np.max(data)
    data_mean = data.mean()
    data_std = data.std()
    data = np.divide((data-data_mean), data_std, out=np.zeros_like(data), where=data_std != 0)

    # min_data = np.min(data)
    # data = (data-min_data)/(para-min_data)
    flow = np.load(path + flow_dataset + '.npy')[0:19872, :, :]
    scale = np.max(flow)
    flow_mean = flow.mean()
    flow_std = flow.std()
    flow = np.divide((flow-flow_mean), flow_std, out=np.zeros_like(flow), where=flow_std != 0)
    # flow, scale =maxminscaler_3d(flow)

    return data, flow, para, scale
    # return flow


def load_distance(path):
    distance = np.load(path + 'distance.npy')
    distance = torch.from_numpy(distance).float().cuda()
    return distance

#最小最大归一化
def maxminscaler_3d(tensor_3d, range = (0,1)):
    scaler_max = tensor_3d.max()
    scaler_min = tensor_3d.min()
    X_std = (tensor_3d - scaler_min)/(scaler_max - scaler_min)
    X_scaled = X_std * (range[1] - range[0]) + range[0]
    return X_scaled, scaler_max

