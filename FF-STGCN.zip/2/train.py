import os
import glob
os.environ["CUDA_VISIBLE_DEVICES"] = "0"
import torch, gc
# !/bin/bash
import torch.nn as nn
from torch.nn import init
from torch.autograd import Variable
import torch.nn.functional as F

from torch.utils.data import DataLoader
gc.collect()
torch.cuda.empty_cache()

import numpy as np
# import pandas as pd
import time

import datetime

from utils import *
from STGNN import STGNN




def train(epoch):
    model.train()

    loss_train_one = torch.zeros(1).cuda()
    loss_train_one_mae = torch.zeros(1).cuda()
    feat_rent_days_tensor = torch.Tensor()
    feat_return_days_tensor = torch.Tensor()
    feat_rent_hours_tensor = torch.Tensor()
    feat_return_hours_tensor = torch.Tensor()
    ground_truth_tensor = torch.Tensor()
    all_hour_idxs = []
    count = 0
    for i in range(train_day * hour):
        count += 1
        feat_rent_days = torch.unsqueeze(torch.from_numpy(rent_flow[day_idxs[i], 0:m_size, 0:m_size]).float(), 0)
        feat_return_days = torch.unsqueeze(torch.from_numpy(return_flow[day_idxs[i], 0:m_size, 0:m_size]).float(), 0)
        feat_rent_hours = torch.unsqueeze(torch.from_numpy(rent_flow[hour_idxs[i], 0:m_size, 0:m_size]).float(), 0)
        feat_return_hours = torch.unsqueeze(torch.from_numpy(return_flow[hour_idxs[i], 0:m_size, 0:m_size]).float(), 0)
        feat_rent_days_tensor = torch.cat([feat_rent_days_tensor, feat_rent_days], 0)
        feat_return_days_tensor = torch.cat([feat_return_days_tensor, feat_return_days], 0)
        feat_rent_hours_tensor = torch.cat([feat_rent_hours_tensor, feat_rent_hours], 0)
        feat_return_hours_tensor = torch.cat([feat_return_hours_tensor, feat_return_hours], 0)
        # ground_truth_rent = torch.unsqueeze(torch.sum(torch.from_numpy(rent_flow[gt_idxs[i], 0:m_size, 0:m_size]).float(), 0), 0)
        # ground_truth_return = torch.unsqueeze(torch.sum(torch.from_numpy(return_flow[gt_idxs[i], 0:m_size, 0:m_size]).float(), 0), 0)
        ground_truth_rent = rent_data[gt_idxs[i], 0:m_size].reshape(-1, m_size)
        ground_truth_return = return_data[gt_idxs[i], 0:m_size].reshape(-1, m_size)
        ground_truth = torch.unsqueeze(torch.from_numpy(np.concatenate((ground_truth_rent, ground_truth_return), axis=0)).float(),0)
        ground_truth_tensor = torch.cat([ground_truth_tensor, ground_truth],0)

        if count % batch_size == 0:
            all_hour_idxs.append(hour_idxs[i])
            a = np.array(all_hour_idxs)
            batch_size_hour_idxs = a.flatten()
            batch_size_hour_idxs = batch_size_hour_idxs[len(batch_size_hour_idxs) - 11:len(batch_size_hour_idxs) - 1]
            feat_rent_days_tensor = feat_rent_days_tensor.cuda()
            feat_return_days_tensor = feat_return_days_tensor.cuda()
            feat_rent_hours_tensor = feat_rent_hours_tensor.cuda()
            feat_return_hours_tensor = feat_return_hours_tensor.cuda()
            scores = model(feat_rent_days_tensor, feat_rent_hours_tensor, feat_return_days_tensor,
                           feat_return_hours_tensor, batch_size_hour_idxs)
            loss, mae = model.loss1(scores, ground_truth_tensor)
            loss_train_one += loss.cpu()
            loss_train_one_mae += mae.cpu()
            loss.backward()
            optimizer.step()
            optimizer.zero_grad()
            # loss_train_one_mae += model.loss2(scores, ground_truth).cpu()
            feat_rent_days_tensor = torch.Tensor()
            feat_return_days_tensor = torch.Tensor()
            feat_rent_hours_tensor = torch.Tensor()
            feat_return_hours_tensor = torch.Tensor()
            ground_truth_tensor = torch.Tensor()
            all_hour_idxs = []

    print("Epoch:", epoch)
    print("train_loss_mse:", loss_train_one.div(((train_day * hour)/batch_size)))
    print("train_loss_mae:", loss_train_one_mae.div(((train_day * hour) / batch_size)))
        # if (i + 1) % batch_size == 0:
        #     # loss_train = loss_train_one.div(batch_size)
        #     loss_train_mae = loss_train_one_mae.div(batch_size)
        #     # loss_train.backward()
        #     loss_train_mae.backward()
        #     optimizer.step()
        #     optimizer.zero_grad()
        #     # loss_train_one = torch.zeros(1).cuda()
        #     loss_train_one_mae = torch.zeros(1).cuda()
        #     # print('loss_train_mse = ', loss_train.item())
        #     print('loss_train_mae = ', loss_train_mae.item())

    model.eval()
    loss_val_one = torch.zeros(1).cuda()
    feat_rent_days_tensor = torch.Tensor()
    feat_return_days_tensor = torch.Tensor()
    feat_rent_hours_tensor = torch.Tensor()
    feat_return_hours_tensor = torch.Tensor()
    ground_truth_tensor = torch.Tensor()
    loss_val_one_mae = torch.zeros(1).cuda()
    count = 0
    for j in range(train_day * hour, (train_day + vali_day) * hour):
        count += 1
        with torch.no_grad():
            feat_rent_days = torch.unsqueeze(torch.from_numpy(rent_flow[day_idxs[j], 0:m_size, 0:m_size]).float(), 0)
            feat_return_days = torch.unsqueeze(torch.from_numpy(return_flow[day_idxs[j], 0:m_size, 0:m_size]).float(),
                                               0)
            feat_rent_hours = torch.unsqueeze(torch.from_numpy(rent_flow[hour_idxs[j], 0:m_size, 0:m_size]).float(), 0)
            feat_return_hours = torch.unsqueeze(torch.from_numpy(return_flow[hour_idxs[j], 0:m_size, 0:m_size]).float(),
                                                0)
            feat_rent_days_tensor = torch.cat([feat_rent_days_tensor, feat_rent_days], 0)
            feat_return_days_tensor = torch.cat([feat_return_days_tensor, feat_return_days], 0)
            feat_rent_hours_tensor = torch.cat([feat_rent_hours_tensor, feat_rent_hours], 0)
            feat_return_hours_tensor = torch.cat([feat_return_hours_tensor, feat_return_hours], 0)
            # ground_truth_rent = torch.unsqueeze(torch.from_numpy(rent_flow[gt_idxs[j], 0:m_size, 0:m_size]).float(), 0)
            # ground_truth_return = torch.unsqueeze(torch.from_numpy(return_flow[gt_idxs[j], 0:m_size, 0:m_size]).float(), 0)
            ground_truth_rent = rent_data[gt_idxs[j], 0:m_size].reshape(-1, m_size)
            ground_truth_return = return_data[gt_idxs[j], 0:m_size].reshape(-1, m_size)
            ground_truth = torch.unsqueeze(torch.from_numpy(np.concatenate((ground_truth_rent, ground_truth_return), axis=0)).float(), 0)
            ground_truth_tensor = torch.cat([ground_truth_tensor, ground_truth], 0)
            if count % batch_size == 0:
                all_hour_idxs.append(hour_idxs[j])
                a = np.array(all_hour_idxs)
                batch_size_hour_idxs = a.flatten()
                batch_size_hour_idxs = batch_size_hour_idxs[
                                       len(batch_size_hour_idxs) - 11:len(batch_size_hour_idxs) - 1]
                feat_rent_days_tensor = feat_rent_days_tensor.cuda()
                feat_return_days_tensor = feat_return_days_tensor.cuda()
                feat_rent_hours_tensor = feat_rent_hours_tensor.cuda()
                feat_return_hours_tensor = feat_return_hours_tensor.cuda()
                scores = model(feat_rent_days_tensor, feat_rent_hours_tensor, feat_return_days_tensor,
                               feat_return_hours_tensor, batch_size_hour_idxs)

                loss2, mae2 = model.loss1(scores, ground_truth_tensor)
                loss_val_one += loss2.cpu()
                loss_val_one_mae += mae2.cpu()
                feat_rent_days_tensor = torch.Tensor()
                feat_return_days_tensor = torch.Tensor()
                feat_rent_hours_tensor = torch.Tensor()
                feat_return_hours_tensor = torch.Tensor()
                ground_truth_tensor = torch.Tensor()
                all_hour_idxs = []
            # loss_val_one_mae += model.loss2(scores, ground_truth).cpu()
    loss_val = loss_val_one.div((vali_day * hour)/batch_size)
    loss_val_mae = loss_val_one_mae.div((vali_day * hour)/batch_size)
    print('-----------------------------------')
    print('loss_val_mse = ', loss_val.item())
    print('loss_val_mae = ', loss_val_mae.item())
    # return loss_val_mae.item()
    return loss_val.item()
def test():
    model.eval()
    all_hour_idxs = []
    loss_test_one = torch.zeros(1).cuda()
    loss_test_one_mae = torch.zeros(1).cuda()
    feat_rent_days_tensor = torch.Tensor()
    feat_return_days_tensor = torch.Tensor()
    feat_rent_hours_tensor = torch.Tensor()
    feat_return_hours_tensor = torch.Tensor()
    ground_truth_tensor = torch.Tensor()
    count = 0
    scoreTensor = torch.Tensor().cuda()
    allground = torch.Tensor()
    for i in range((train_day + vali_day)*hour, (train_day + vali_day + test_day) * hour):
        count += 1
        # feat_rent_days = torch.unsqueeze(torch.from_numpy(rent_flow[day_idxs[i], 0:m_size, 0:m_size]).float(), 0)
        # feat_return_days = torch.unsqueeze(torch.from_numpy(return_flow[day_idxs[i], 0:m_size, 0:m_size]).float(), 0)
        # feat_rent_hours = torch.unsqueeze(torch.from_numpy(rent_flow[hour_idxs[i], 0:m_size, 0:m_size]).float(), 0)
        # feat_return_hours = torch.unsqueeze(torch.from_numpy(return_flow[hour_idxs[i], 0:m_size, 0:m_size]).float(), 0)
        # feat_rent_days_tensor = torch.cat([feat_rent_days_tensor, feat_rent_days], 0)
        # feat_return_days_tensor = torch.cat([feat_return_days_tensor, feat_return_days], 0)
        # feat_rent_hours_tensor = torch.cat([feat_rent_hours_tensor, feat_rent_hours], 0)
        # feat_return_hours_tensor = torch.cat([feat_return_hours_tensor, feat_return_hours], 0)
        # ground_truth_rent = torch.unsqueeze(torch.from_numpy(rent_flow[gt_idxs[i], 0:m_size, 0:m_size]).float(), 0)
        # ground_truth_return = torch.unsqueeze(torch.from_numpy(return_flow[gt_idxs[i], 0:m_size, 0:m_size]).float(), 0)
        ground_truth_rent = rent_data[gt_idxs[i], 0:m_size].reshape(-1, m_size)
        ground_truth_return = return_data[gt_idxs[i], 0:m_size].reshape(-1, m_size)
        ground_truth = torch.unsqueeze(torch.from_numpy(np.concatenate((ground_truth_rent, ground_truth_return), axis=0)).float(),0)
        ground_truth_tensor = torch.cat([ground_truth_tensor, ground_truth], 0)
    np.save('y_true.npy', ground_truth_tensor)
    #     if count % batch_size == 0:
    #         all_hour_idxs.append(hour_idxs[i])
    #         a = np.array(all_hour_idxs)
    #         batch_size_hour_idxs = a.flatten()
    #         batch_size_hour_idxs = batch_size_hour_idxs[len(batch_size_hour_idxs) - 11:len(batch_size_hour_idxs) - 1]
    #         feat_rent_days_tensor = feat_rent_days_tensor.cuda()
    #         feat_return_days_tensor = feat_return_days_tensor.cuda()
    #         feat_rent_hours_tensor = feat_rent_hours_tensor.cuda()
    #         feat_return_hours_tensor = feat_return_hours_tensor.cuda()
    #         scores = model(feat_rent_days_tensor, feat_rent_hours_tensor, feat_return_days_tensor,
    #                        feat_return_hours_tensor, batch_size_hour_idxs)
    #         scoreTensor = torch.cat((scores, scoreTensor), 0)
    #         allground = torch.cat((ground_truth_tensor, allground), 0)
    #         loss, mae = model.loss1(scores, ground_truth_tensor)
    #         loss_test_one += loss.cpu()
    #         loss_test_one_mae += mae.cpu()
    #         # loss_train_one_mae += model.loss2(scores, ground_truth).cpu()
    #         feat_rent_days_tensor = torch.Tensor()
    #         feat_return_days_tensor = torch.Tensor()
    #         feat_rent_hours_tensor = torch.Tensor()
    #         feat_return_hours_tensor = torch.Tensor()
    #         ground_truth_tensor = torch.Tensor()
    #         all_hour_idxs = []
    #     # loss_test_one_mae += model.loss2(pre, ground_truth).cpu()
    #     #
    #     # result.append(pre.detach().cpu().numpy())
    #     # ground.append(ground_truth)
    #
    # # result = np.array(result)
    # # ground = np.array(ground)
    # loss_test = loss_test_one.div((test_day * hour)/batch_size)
    # loss_test_mae = loss_test_one_mae.div((test_day * hour)/batch_size)
    # print('-----------------------------------')
    # print('loss_test_mse = ', loss_test.item())
    # print('loss_test_mae = ', loss_test_mae.item())
    # np.save('per_15min.npy', scoreTensor.cpu())
    # # return loss_test_mae
    # return loss_test
start_time = time.time()


# path = 'data/la/'
#
#
# rent_dataset = 'pickup'
# rent_flow_dataset = 'sparse_rent2return'
#
# return_dataset = 'dropoff'
# return_flow_dataset = 'sparse_return2rent'
#
# #all day
# day = 7
# hour = 96
# m_size = 135
#
# train_day = 60
# vali_day = 30
# test_day = 450
path = 'data/NewYork/'
rent_dataset = 'pickup_120_9936'
rent_flow_dataset = 'rent2return_120_9936'
return_dataset = 'dropoff_120_9936'
return_flow_dataset = 'return2rent_120_9936'

#all day
day = 7
hour = 48
# m_size = 330
m_size = 120
train_day = 140
vali_day = 20
test_day = 40

# # weekday
# day = 5
# hour = 96
# m_size = 135

# train_day = 43
# vali_day = 21
# test_day = 320

# # weekend
# day = 2
# hour = 96
# m_size = 135

# train_day = 17
# vali_day = 9
# test_day = 129


learning_rate = 0.001

epoch_no = 100
batch_size = 32
embed_dim = 8
feature_dim = m_size * 4

# feature_dim = m_size*2

# rent_flow = load_dataset(path, rent_dataset, rent_flow_dataset, m_size)
# return_flow = load_dataset(path, return_dataset, return_flow_dataset, m_size)
rent_data, rent_flow, rent_para, scale = load_dataset(path, rent_dataset, rent_flow_dataset, m_size)
return_data, return_flow, return_para, scale = load_dataset(path, return_dataset, return_flow_dataset, m_size)
difference = np.array(torch.tensor(np.load('data/NewYork/difference_15min_120.npy')))
pearson = np.array(torch.tensor(np.load('data/NewYork/pearsonr.npy')))[0:m_size, 0:m_size]

# distance = load_distance(path)
day_idxs = []
hour_idxs = []
gt_idxs = []

for n in range(day * hour, (day + train_day + vali_day + test_day) * hour):
    day_idxs.append([(n - i) for i in range((day) * hour, 0, -hour)])
    hour_idxs.append(list(range((n - hour), n)))
    gt_idxs.append(n)


model = STGNN(feature_dim, embed_dim, m_size, day, hour, batch_size,difference, pearson)
# model.load_state_dict(torch.load('data/NewYork/Result_15min/32.pkl'))
optimizer = torch.optim.Adam(filter(lambda p: p.requires_grad, model.parameters()), lr = learning_rate)
scheduler = torch.optim.lr_scheduler.StepLR(optimizer, step_size = 5, gamma=0.2)


loss_values = []
bad_counter = 0
best = epoch_no + 1
best_epoch = 0


for epoch in range(epoch_no):
    print('Training Process: epoch = ', epoch)
    loss_values.append(train(epoch))
    scheduler.step()
    torch.save(model.state_dict(), path + '/Result_15min_New/' +'{}.pkl'.format(epoch))
    if loss_values[-1] <= best:
        best = loss_values[-1]
        best_epoch = epoch
        bad_counter = 0
    else:
        bad_counter += 1

    if bad_counter == 10:
        break

    files = glob.glob(path + '/Result/' + '*.pkl')
    for file in files:
        epoch_nb = int((file.split('.')[0]).split('/')[-1])
        if epoch_nb < best_epoch:
            os.remove(file)
#
# files = glob.glob(path + '/Result/' + '*.pkl')
# for file in files:
#     epoch_nb = int((file.split('.')[0]).split('/')[-1])
#     if epoch_nb > best_epoch:
#         os.remove(file)
#     Save Parameters

#     torch.save(model.state_dict(), path + station + '/' + station + '.pkl')
with torch.no_grad():
    test()
    # loss_test = test()

# df1 = predict
# np.save(path + 'Result/'+ 'pr.npy', df1)
# df2 = ground_truth
# np.save(path + 'Result/' + 'gt.npy', df2)



# end_time = time.time()
# times = end_time - start_time
# print('Total_time =',times)
# torch.cuda.empty_cache()
# print('max = ', para)


